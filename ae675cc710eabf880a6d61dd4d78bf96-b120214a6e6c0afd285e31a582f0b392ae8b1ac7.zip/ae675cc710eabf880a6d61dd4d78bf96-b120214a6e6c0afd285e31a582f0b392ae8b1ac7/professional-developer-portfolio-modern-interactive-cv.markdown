Professional Developer Portfolio - Modern & Interactive CV
----------------------------------------------------------

A stunning, fully-responsive portfolio website with advanced animations, multi-language support, and code-themed design. Perfect for developers and tech professionals.

## Features

- Modern code-themed design with beautiful gradients
- Smooth animations powered by Anime.js
- Multi-language support (English & Arabic) with RTL/LTR
- Fully responsive mobile-first design
- Dark and Light theme support
- Interactive hover effects and scroll animations
- Parallax effects and smooth scrolling
- Performance optimized

## Technologies

- HTML5
- CSS3 (Custom Properties, Grid, Flexbox)
- JavaScript (ES6+)
- Anime.js
- Tailwind CSS
- Font Awesome Icons
- Tajawal & Fira Code Fonts

## Sections

- Hero Section with animated introduction
- About Me with statistics
- Skills with animated progress bars
- Experience timeline with achievements
- Projects showcase
- Contact form

## Quick Start

1. Open `index.html` in your browser
2. Customize content with your information
3. Update colors in CSS variables
4. Deploy to your hosting platform

## Browser Support

Chrome, Firefox, Safari, Edge (latest versions)

## License

Free to use for personal and commercial projects.

## Credits

Developer: Kan3an  
LinkedIn: [Mohammad Abu Sakour](https://www.linkedin.com/in/mohammad-abu-sakour-kn)

---

## Tags

#portfolio #webdev #frontend #javascript #css #html #animation #responsive #webdesign #developer #codepen #ui #ux #modern #interactive #cv #resume #portfolio-website #web-development #animejs #tailwindcss #multilanguage #rtl #arabic #english #darkmode #parallax #smooth-scroll #glassmorphism #gradient #code-themed #professional #freelance #tech-portfolio #developer-portfolio #responsive-portfolio #mobile-friendly #performance #optimized


A [Pen](https://codepen.io/Kan3an/pen/qEZzbom) by [Kan3an](https://codepen.io/Kan3an) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/qEZzbom).